# Licensing Options for FrequenCipher

FrequenCipher offers flexible licensing models to fit organizations of all sizes:

- **Community Edition (Free):** Limited analyses per month, watermarked reports; ideal for students and hobbyists.
- **Professional License (SaaS):** Subscription-based access to our cloud service with advanced features and priority support.
- **Enterprise License:** Annual fee for on-premises deployments, custom integrations, and dedicated support.
- **OEM/API Licensing:** Integrate FrequenCipher into your product via our API. Pricing based on volume and usage.

Contact sales@frequencipher.com for a custom quote.
